import React from 'react'

const favorites = () => {
  return (
    <div>
      
    </div>
  )
}

export default favorites
